import { Bell, Search, UserCircle, ChevronDown } from 'lucide-react';

export default function Header({ title }) {
  return (
    <header className="header">
      <div>
        <h1 className="text-xl">{title}</h1>
      </div>
      
      <div className="flex items-center gap-6">
        <div style={{ position: 'relative' }}>
          <Search size={18} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
          <input 
            type="text" 
            placeholder="Search interaction ID..." 
            className="input"
            style={{ paddingLeft: '2.5rem', width: '250px' }}
          />
        </div>
        
        <div style={{ position: 'relative', cursor: 'pointer' }}>
          <Bell size={20} className="text-muted hover:text-main transition" />
          <span style={{ position: 'absolute', top: -4, right: -4, width: 8, height: 8, borderRadius: '50%', background: 'var(--accent)' }}></span>
        </div>
        
        <div className="flex items-center gap-2" style={{ cursor: 'pointer' }}>
          <UserCircle size={28} className="text-primary" />
          <div className="flex-col" style={{ lineHeight: 1.2 }}>
            <span className="text-sm font-medium">Admin User</span>
            <span className="text-xs text-muted">Quality Assurance</span>
          </div>
          <ChevronDown size={16} className="text-muted" />
        </div>
      </div>
    </header>
  );
}
