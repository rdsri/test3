import { NavLink } from 'react-router-dom';
import { BarChart2, BookOpen, ShieldPlus, FlaskConical, Activity } from 'lucide-react';

export default function Sidebar() {
  const navItems = [
    { name: 'Analytics',   path: '/',         icon: <BarChart2  size={20} />, badge: null },
    { name: 'AI Courses',  path: '/courses',  icon: <BookOpen   size={20} />, badge: null },
    { name: 'RCA Analysis', path: '/rca',      icon: <FlaskConical size={20} />, badge: null },
    { name: 'CAPA',         path: '/capa',     icon: <ShieldPlus size={20} />, badge: null },
  ];

  return (
    <aside className="sidebar">
      <div className="logo">
        <div className="logo-icon">
          <Activity size={24} color="#fff" />
        </div>
        <span>NexusAudit</span>
      </div>

      <nav style={{ display: 'flex', flexDirection: 'column' }}>
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            end={item.path === '/'}
            className={({ isActive }) => (isActive ? 'nav-item active' : 'nav-item')}
          >
            {item.icon}
            <span style={{ flex: 1 }}>{item.name}</span>
            {item.badge && (
              <span style={{
                fontSize: '0.6rem', fontWeight: 700, padding: '2px 6px',
                background: 'rgba(139,92,246,0.2)', color: 'var(--primary)',
                borderRadius: '999px', letterSpacing: '0.05em'
              }}>{item.badge}</span>
            )}
          </NavLink>
        ))}
      </nav>

      <div style={{ marginTop: 'auto' }} className="glass-panel p-4">
        <div className="text-sm font-semibold mb-2">System Status</div>
        <div className="flex items-center gap-2 text-xs text-muted">
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--success)', boxShadow: '0 0 8px var(--success)' }}></div>
          LLM Engine Online
        </div>
      </div>
    </aside>
  );
}
