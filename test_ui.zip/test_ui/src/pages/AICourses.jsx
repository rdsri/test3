import { useState } from 'react';
import {
  ChevronDown, ChevronUp, AlertTriangle, AlertCircle, Info,
  BookOpen, Clock, BarChart2, Play, ExternalLink, CheckCircle2,
  Brain, ShieldCheck, Smile, TrendingUp, Scale, Zap, Users
} from 'lucide-react';
import './AICourses.css';

/* ─────────── DATA ─────────── */
const GROUPS = [
  {
    id: 'g2',
    imu: 'Sales', client: 'Globex', process: 'Onboarding', geo: 'EMEA',
    health: 61,
    issues: [
      {
        id: 'i1', severity: 'high', category: 'Resolution Rate',
        icon: <TrendingUp size={16}/>, color: '#f43f5e',
        title: 'Low Call Resolution Rate',
        explanation: 'Only 72% of interactions are resolved on first contact — 13% below the 85% threshold. Agents are closing calls without confirming customer satisfaction or escalating unresolved cases properly.',
        courses: [
          { id: 'c1', title: 'Mastering First-Call Resolution', description: 'Strategies and communication frameworks to resolve customer issues in a single interaction.', skill: 'Resolution Techniques', duration: '3h 20m', level: 'Intermediate', levelColor: '#f59e0b' },
          { id: 'c2', title: 'Effective Call Closing Strategies', description: 'How to confirm issue resolution before ending a call and set correct expectations.', skill: 'Call Management', duration: '1h 45m', level: 'Beginner', levelColor: '#10b981' },
        ]
      },
      {
        id: 'i2', severity: 'high', category: 'Compliance',
        icon: <ShieldCheck size={16}/>, color: '#f59e0b',
        title: 'Compliance Adherence Below Benchmark',
        explanation: 'Compliance score stands at 78%, falling below the 90% threshold by 12%. Agents are missing mandatory disclosure statements and failing to follow GDPR-related data collection protocols.',
        courses: [
          { id: 'c3', title: 'Regulatory Compliance in Customer Service', description: 'Deep-dive into data privacy laws, mandatory disclosures, and compliance checklists for agents.', skill: 'Data Privacy & GDPR', duration: '2h 30m', level: 'Advanced', levelColor: '#f43f5e' },
          { id: 'c4', title: 'Call Compliance Fundamentals', description: 'Core compliance rules every agent must follow during customer interactions.', skill: 'Compliance Protocols', duration: '1h 10m', level: 'Beginner', levelColor: '#10b981' },
        ]
      },
      {
        id: 'i3', severity: 'medium', category: 'Sentiment',
        icon: <Smile size={16}/>, color: '#ec4899',
        title: 'Positive Sentiment Deficiency',
        explanation: 'Positive sentiment detected in only 58% of interactions, below the 75% threshold. Analysis shows lack of empathetic language and excessive use of scripted, robotic responses.',
        courses: [
          { id: 'c5', title: 'Empathy in Customer Communication', description: 'Behavioral techniques to build rapport, acknowledge frustration, and convey genuine care.', skill: 'Emotional Intelligence', duration: '2h 00m', level: 'Intermediate', levelColor: '#f59e0b' },
        ]
      },
    ]
  },
  {
    id: 'g4',
    imu: 'Tech Support', client: 'Hooli', process: 'Tech Setup', geo: 'LATAM',
    health: 44,
    issues: [
      {
        id: 'i4', severity: 'high', category: 'NPS Score',
        icon: <BarChart2 size={16}/>, color: '#8b5cf6',
        title: 'Critically Low NPS Score',
        explanation: 'NPS of 3.9 is drastically below the 7.5 threshold. Customer feedback indicates lack of product knowledge, poor troubleshooting guidance, and excessive hold times during technical setups.',
        courses: [
          { id: 'c6', title: 'Advanced Technical Troubleshooting Skills', description: 'Build deep product knowledge and structured problem-solving approaches for technical issues.', skill: 'Technical Expertise', duration: '4h 15m', level: 'Advanced', levelColor: '#f43f5e' },
          { id: 'c7', title: 'Improving NPS Through Service Excellence', description: 'Data-driven techniques to increase customer satisfaction scores during support interactions.', skill: 'Customer Experience', duration: '2h 45m', level: 'Intermediate', levelColor: '#f59e0b' },
        ]
      },
      {
        id: 'i5', severity: 'high', category: 'Risk Rate',
        icon: <AlertTriangle size={16}/>, color: '#f43f5e',
        title: 'Elevated Risk Rate (34%)',
        explanation: 'Risk rate at 34% — well above the ≤10% threshold. High-risk flags are triggered by agents sharing incorrect technical instructions, causing potential liability and customer harm.',
        courses: [
          { id: 'c8', title: 'Risk Identification & Mitigation in Support Calls', description: 'Learn to identify at-risk situations during calls and apply de-escalation or correct procedures.', skill: 'Risk Management', duration: '3h 00m', level: 'Advanced', levelColor: '#f43f5e' },
          { id: 'c9', title: 'Accurate Information Delivery for Tech Agents', description: 'How to verify and communicate technical instructions clearly to prevent errors.', skill: 'Knowledge Accuracy', duration: '1h 50m', level: 'Intermediate', levelColor: '#f59e0b' },
        ]
      },
      {
        id: 'i6', severity: 'high', category: 'AI Score',
        icon: <Brain size={16}/>, color: '#0ea5e9',
        title: 'Low AI Evaluation Score',
        explanation: 'AI score of 52% is far below the 80% threshold. The model identifies poor structure in responses, failure to use active listening cues, and inconsistent use of the approved agent script.',
        courses: [
          { id: 'c10', title: 'Structured Agent Communication Framework', description: 'Step-by-step guide to structuring responses using open-loop questions and active listening.', skill: 'Communication Structure', duration: '2h 20m', level: 'Intermediate', levelColor: '#f59e0b' },
        ]
      },
    ]
  },
  {
    id: 'g6',
    imu: 'Customer Service', client: 'Globex', process: 'Billing', geo: 'EMEA',
    health: 55,
    issues: [
      {
        id: 'i7', severity: 'high', category: 'Escalation Rate',
        icon: <Zap size={16}/>, color: '#fb923c',
        title: 'High Escalation Rate (19%)',
        explanation: 'Escalation rate of 19% exceeds the ≤8% threshold by 11%. Root cause: agents lack billing system knowledge and cannot address common disputes directly, resulting in unnecessary escalations.',
        courses: [
          { id: 'c11', title: 'Billing Dispute Resolution Mastery', description: 'Equips agents to handle billing queries confidently without supervisor escalation.', skill: 'Billing System Expertise', duration: '3h 35m', level: 'Advanced', levelColor: '#f43f5e' },
          { id: 'c12', title: 'De-escalation Techniques for Service Teams', description: 'Practical scenarios for calming upset customers and resolving issues at the agent level.', skill: 'De-escalation', duration: '2h 10m', level: 'Intermediate', levelColor: '#f59e0b' },
        ]
      },
      {
        id: 'i8', severity: 'medium', category: 'CAST Score',
        icon: <Scale size={16}/>, color: '#14b8a6',
        title: 'Below-Threshold CAST Score',
        explanation: 'CAST score of 55% falls below the 70% threshold. Agents are not following the call assessment structure — missing call opening scripts, mid-call checkpoints, and closing confirmation steps.',
        courses: [
          { id: 'c13', title: 'CAST Framework for Service Agents', description: 'Understand and implement the full Call Assessment Structure and Technique (CAST) model.', skill: 'Call Structure', duration: '1h 55m', level: 'Beginner', levelColor: '#10b981' },
        ]
      },
    ]
  },
  {
    id: 'g3',
    imu: 'Customer Service', client: 'Initech', process: 'Troubleshooting', geo: 'APAC',
    health: 78,
    issues: [
      {
        id: 'i9', severity: 'medium', category: 'Compliance',
        icon: <ShieldCheck size={16}/>, color: '#f59e0b',
        title: 'Compliance Slightly Below Benchmark',
        explanation: 'Compliance at 85%, below the 90% threshold. Minor procedural gaps — specifically around post-call summary and consent verification — are affecting the score.',
        courses: [
          { id: 'c14', title: 'Post-Call Compliance Checklist Training', description: 'Best practices for completing post-call steps including consent capture and case documentation.', skill: 'Post-Call Process', duration: '0h 55m', level: 'Beginner', levelColor: '#10b981' },
        ]
      },
    ]
  },
];

/* ─────────── HELPERS ─────────── */
const SEVERITY_CONFIG = {
  high:   { label: 'High',   bg: 'rgba(244,63,94,0.12)',  color: '#f43f5e', icon: <AlertTriangle size={13}/> },
  medium: { label: 'Medium', bg: 'rgba(245,158,11,0.12)', color: '#f59e0b', icon: <AlertCircle size={13}/> },
  low:    { label: 'Low',    bg: 'rgba(16,185,129,0.12)', color: '#10b981', icon: <Info size={13}/> },
};

function healthColor(h) {
  if (h >= 80) return 'var(--success)';
  if (h >= 60) return 'var(--warning)';
  return 'var(--danger)';
}

/* ─────────── COURSE CARD ─────────── */
function CourseCard({ course }) {
  return (
    <div className="course-card">
      <div className="course-card-header">
        <div className="course-icon-wrap">
          <BookOpen size={18} color="var(--primary)" />
        </div>
        <div className="course-meta">
          <span className="course-level" style={{ color: course.levelColor, background: `${course.levelColor}18` }}>
            {course.level}
          </span>
          <span className="course-duration flex gap-2 items-center text-muted">
            <Clock size={11} /> {course.duration}
          </span>
        </div>
      </div>
      <h4 className="course-title">{course.title}</h4>
      <p className="course-desc">{course.description}</p>
      <div className="course-skill">
        <BarChart2 size={12} />
        <span>{course.skill}</span>
      </div>
      <div className="course-actions">
        <button className="btn btn-primary course-btn">
          <Play size={13} /> Start Course
        </button>
        <button className="btn btn-secondary course-btn">
          <ExternalLink size={13} /> Preview
        </button>
      </div>
    </div>
  );
}

/* ─────────── ISSUE ROW ─────────── */
function IssueRow({ issue }) {
  const [open, setOpen] = useState(false);
  const sev = SEVERITY_CONFIG[issue.severity];

  return (
    <div className={`issue-row ${open ? 'open' : ''}`}>
      <div className="issue-header" onClick={() => setOpen(o => !o)}>
        <div className="issue-header-left">
          <div className="issue-cat-icon" style={{ color: issue.color, background: `${issue.color}18` }}>
            {issue.icon}
          </div>
          <div>
            <div className="issue-title">{issue.title}</div>
            <div className="issue-cat-label">{issue.category}</div>
          </div>
        </div>
        <div className="issue-header-right">
          <span className="sev-badge" style={{ color: sev.color, background: sev.bg }}>
            {sev.icon} {sev.label} Risk
          </span>
          <span className="issue-course-count">
            {issue.courses.length} course{issue.courses.length > 1 ? 's' : ''}
          </span>
          {open ? <ChevronUp size={16} className="text-muted" /> : <ChevronDown size={16} className="text-muted" />}
        </div>
      </div>

      {open && (
        <div className="issue-body">
          <div className="rca-box">
            <div className="rca-label"><AlertCircle size={12} /> Root Cause Analysis</div>
            <p className="rca-text">{issue.explanation}</p>
          </div>
          <div className="courses-label">
            <BookOpen size={13} /> Recommended Courses to Resolve This Issue
          </div>
          <div className="courses-grid">
            {issue.courses.map(c => <CourseCard key={c.id} course={c} />)}
          </div>
        </div>
      )}
    </div>
  );
}

/* ─────────── GROUP SECTION ─────────── */
function GroupSection({ group }) {
  const [collapsed, setCollapsed] = useState(false);
  const highCount = group.issues.filter(i => i.severity === 'high').length;
  const hColor = healthColor(group.health);

  return (
    <div className="group-section glass-panel">
      <div className="group-section-header" onClick={() => setCollapsed(c => !c)}>
        <div className="group-section-left">
          <div className="group-stripe" style={{ background: hColor }} />
          <div>
            <h3 className="group-section-title">
              {group.imu} · {group.client}
            </h3>
            <p className="group-section-sub">{group.process} · {group.geo}</p>
          </div>
        </div>
        <div className="group-section-right">
          <span className="group-health" style={{ color: hColor }}>
            Health: <strong>{group.health}</strong>
          </span>
          {highCount > 0 && (
            <span className="sev-badge" style={{ color: '#f43f5e', background: 'rgba(244,63,94,0.12)' }}>
              <AlertTriangle size={11} /> {highCount} High-Risk
            </span>
          )}
          <span className="sev-badge" style={{ color: 'var(--text-muted)', background: 'rgba(255,255,255,0.06)' }}>
            {group.issues.length} Issues
          </span>
          {collapsed
            ? <ChevronDown size={18} className="text-muted" />
            : <ChevronUp size={18} className="text-muted" />}
        </div>
      </div>

      {!collapsed && (
        <div className="group-issues">
          {group.issues.map(issue => (
            <IssueRow key={issue.id} issue={issue} />
          ))}
        </div>
      )}
    </div>
  );
}

/* ─────────── SUMMARY BAR ─────────── */
function SummaryBar() {
  const totalIssues  = GROUPS.reduce((a, g) => a + g.issues.length, 0);
  const highIssues   = GROUPS.reduce((a, g) => a + g.issues.filter(i => i.severity === 'high').length, 0);
  const totalCourses = GROUPS.reduce((a, g) => a + g.issues.reduce((b, i) => b + i.courses.length, 0), 0);
  const groups       = GROUPS.length;

  return (
    <div className="summary-bar">
      {[
        { label: 'Groups Analyzed', value: groups,       color: 'var(--primary)',  icon: <Users size={18}/> },
        { label: 'Total RCA Issues', value: totalIssues, color: 'var(--warning)',  icon: <AlertCircle size={18}/> },
        { label: 'High-Risk Issues', value: highIssues,  color: 'var(--danger)',   icon: <AlertTriangle size={18}/> },
        { label: 'Courses Available', value: totalCourses, color: 'var(--success)', icon: <BookOpen size={18}/> },
      ].map((s, i) => (
        <div key={i} className="summary-stat glass-panel">
          <div className="summary-icon" style={{ color: s.color, background: `${s.color}18` }}>{s.icon}</div>
          <div>
            <div className="summary-value" style={{ color: s.color }}>{s.value}</div>
            <div className="summary-label">{s.label}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ─────────── PAGE ─────────── */
export default function AICourses() {
  const [filter, setFilter] = useState('all');

  const filtered = GROUPS.filter(g => {
    if (filter === 'high')   return g.issues.some(i => i.severity === 'high');
    if (filter === 'medium') return g.issues.some(i => i.severity === 'medium');
    return true;
  });

  return (
    <div className="aicourses-root animate-fade-in">
      {/* Page intro */}
      <div className="ai-page-intro">
        <div>
          <h1 className="text-2xl">AI-Recommended Courses</h1>
          <p className="text-muted" style={{ marginTop: 4, fontSize: '0.875rem' }}>
            Resolve identified RCA issues with targeted learning — linked by group performance gaps
          </p>
        </div>
        <div className="filter-tabs">
          {[
            { value: 'all',    label: 'All Groups' },
            { value: 'high',   label: '🔴 High Risk' },
            { value: 'medium', label: '🟡 Medium Risk' },
          ].map(f => (
            <button
              key={f.value}
              className={`filter-tab ${filter === f.value ? 'active' : ''}`}
              onClick={() => setFilter(f.value)}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Summary Stats */}
      <SummaryBar />

      {/* Groups */}
      <div className="groups-list">
        {filtered.map(g => <GroupSection key={g.id} group={g} />)}
      </div>
    </div>
  );
}
