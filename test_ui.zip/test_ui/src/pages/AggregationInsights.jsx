import { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { Settings, SlidersHorizontal, TriangleAlert, Target } from 'lucide-react';

const processData = [
  { process: 'Onboarding', avgWait: 120, satisfaction: 8.5 },
  { process: 'Billing', avgWait: 210, satisfaction: 6.2 },
  { process: 'Tech Support', avgWait: 340, satisfaction: 5.8 },
  { process: 'Sales Inq.', avgWait: 45, satisfaction: 9.1 },
];

export default function AggregationInsights() {
  const [activeTab, setActiveTab] = useState('process');
  
  return (
    <div className="animate-fade-in flex flex-col gap-6">
      
      {/* Header and Tabs */}
      <div className="flex justify-between items-center mb-2">
        <div className="flex gap-2 p-1 bg-white/5 rounded-lg border border-white/10">
          {['IMU', 'Client', 'Process', 'Geo'].map((tab) => (
            <button
              key={tab.toLowerCase()}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
                activeTab === tab.toLowerCase() ? 'bg-primary text-white shadow-lg' : 'text-muted hover:text-white'
              }`}
              onClick={() => setActiveTab(tab.toLowerCase())}
            >
              Group By {tab}
            </button>
          ))}
        </div>
        <button className="btn btn-secondary"><Settings size={16} /> Configure Thresholds</button>
      </div>

      <div className="grid grid-cols-3 gap-6">
        
        {/* Main Chart */}
        <div className="glass-panel p-6 col-span-2 flex flex-col">
          <h2 className="text-lg font-semibold mb-6 flex justify-between">
            <span>Aggregated Insights: {activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} Performance</span>
            <span className="text-sm font-normal text-muted flex items-center gap-2"><SlidersHorizontal size={16}/> Adjust Variables</span>
          </h2>
          <div className="flex-1 min-h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={processData} margin={{ left: -20 }}>
                <XAxis dataKey="process" stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis yAxisId="left" stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis yAxisId="right" orientation="right" stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip cursor={{ fill: 'var(--bg-surface-hover)' }} contentStyle={{ background: 'var(--bg-color)', borderColor: 'var(--border-color)', borderRadius: '8px' }} />
                <Bar yAxisId="left" dataKey="avgWait" name="Avg Handle Time (s)" fill="var(--primary)" radius={[4, 4, 0, 0]} />
                <Bar yAxisId="right" dataKey="satisfaction" name="Satisfaction Score" fill="var(--success)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Missed Opportunities / Gaps */}
        <div className="glass-panel p-6 flex flex-col gap-4">
          <div className="flex gap-2 items-center mb-2">
            <TriangleAlert className="text-warning" size={20} />
            <h2 className="text-lg font-semibold text-warning">Missed Opportunities</h2>
          </div>
          <p className="text-sm text-muted mb-2">Threshold breaches identified across groupings.</p>
          
          <div className="flex flex-col gap-3 overflow-y-auto pr-2 custom-scrollbar">
            {/* Gap Card 1 */}
            <div className="p-4 bg-white/5 rounded-lg border border-white/5 hover:border-warning/50 transition">
              <div className="text-sm font-bold flex justify-between">
                <span>Billing Process (Tech)</span>
                <span className="text-danger font-mono">-18%</span>
              </div>
              <div className="text-xs text-muted mt-1">NPS fell below 7.0 threshold. High volume of unresolved queries.</div>
              <div className="mt-3 flex justify-between items-center">
                <span className="text-xs font-semibold px-2 py-1 rounded bg-black/40 text-muted">14 Agents Affected</span>
                <button className="text-xs text-primary hover:text-white transition">Assign Training &rarr;</button>
              </div>
            </div>

            {/* Gap Card 2 */}
            <div className="p-4 bg-white/5 rounded-lg border border-white/5 hover:border-warning/50 transition">
              <div className="text-sm font-bold flex justify-between">
                <span>LATAM (Sales)</span>
                <span className="text-warning font-mono">-12%</span>
              </div>
              <div className="text-xs text-muted mt-1">Compliance adherence dropped below 90% benchmark.</div>
              <div className="mt-3 flex justify-between items-center">
                <span className="text-xs font-semibold px-2 py-1 rounded bg-black/40 text-muted">22 Agents Affected</span>
                <button className="text-xs text-primary hover:text-white transition">Assign Training &rarr;</button>
              </div>
            </div>
            
            <button className="btn btn-secondary w-full mt-2 text-sm">View All 12 Gaps</button>
          </div>
        </div>
      </div>

    </div>
  );
}
