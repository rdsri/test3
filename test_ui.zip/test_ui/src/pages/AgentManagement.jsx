import { Search, GraduationCap, CheckCircle, Clock } from 'lucide-react';

export default function AgentManagement() {
  const agents = [
    { id: 'AG-103', name: 'Sarah Jenkins', geo: 'NA', group: 'Tech / Billing', score: 6.8, gap: 'Resolution Time', course: 'Advanced Troubleshooting', status: 'In Progress', progress: 45 },
    { id: 'AG-294', name: 'Marcus Chen', geo: 'APAC', group: 'Sales / Onboard', score: 9.2, gap: 'None', course: 'N/A', status: 'Completed', progress: 100 },
    { id: 'AG-155', name: 'Elena Rodriguez', geo: 'LATAM', group: 'Support / Acme', score: 4.5, gap: 'Empathy & Tone', course: 'Customer De-escalation', status: 'Assigned', progress: 0 },
    { id: 'AG-442', name: 'James Wilson', geo: 'EMEA', group: 'Tech / Setup', score: 7.1, gap: 'Compliance', course: 'Data Privacy V2', status: 'Completed', progress: 100 },
  ];

  return (
    <div className="animate-fade-in flex flex-col gap-6">
      
      {/* Top Controls */}
      <div className="glass-panel p-4 flex justify-between items-center">
        <div className="relative w-1/3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" size={18} />
          <input type="text" placeholder="Search agents..." className="input w-full pl-10" />
        </div>
        <div className="flex gap-4">
          <select className="select">
            <option>All Geos</option>
            <option>NA</option>
            <option>EMEA</option>
            <option>APAC</option>
          </select>
          <select className="select">
            <option>Course Status</option>
            <option>Assigned</option>
            <option>In Progress</option>
            <option>Completed</option>
          </select>
          <button className="btn btn-primary"><GraduationCap size={16} /> Bulk Assign Course</button>
        </div>
      </div>

      {/* Agents Table */}
      <div className="glass-panel overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-black/20 border-b border-white/10 text-muted uppercase text-xs tracking-wider">
              <th className="p-4 font-medium">Agent</th>
              <th className="p-4 font-medium">Assignment Group</th>
              <th className="p-4 font-medium">Performance Score</th>
              <th className="p-4 font-medium">Identified Gap</th>
              <th className="p-4 font-medium">Active Training</th>
              <th className="p-4 font-medium">Course Status</th>
              <th className="p-4 font-medium">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {agents.map((agent) => (
              <tr key={agent.id} className="hover:bg-white/5 transition-colors">
                <td className="p-4">
                  <div className="font-semibold">{agent.name}</div>
                  <div className="text-xs text-muted">{agent.id} • {agent.geo}</div>
                </td>
                <td className="p-4 text-sm text-muted">{agent.group}</td>
                <td className="p-4">
                  <span className={`font-bold ${agent.score >= 8 ? 'text-success' : agent.score < 6 ? 'text-danger' : 'text-warning'}`}>
                    {agent.score} / 10
                  </span>
                </td>
                <td className="p-4 text-sm text-danger">{agent.gap !== 'None' ? agent.gap : <span className="text-muted">-</span>}</td>
                <td className="p-4 text-sm font-medium text-blue-400">{agent.course !== 'N/A' ? agent.course : <span className="text-muted">-</span>}</td>
                <td className="p-4">
                  {agent.course === 'N/A' ? <span className="text-muted">-</span> : (
                    <div className="flex flex-col gap-1 w-full max-w-[150px]">
                      <div className="flex justify-between text-xs">
                        <span className={agent.status === 'Completed' ? 'text-success' : 'text-muted'}>{agent.status}</span>
                        <span>{agent.progress}%</span>
                      </div>
                      <div className="progress-bg h-1.5">
                        <div className={`h-full rounded-full ${agent.status === 'Completed' ? 'bg-success' : 'bg-primary'}`} style={{ width: `${agent.progress}%` }}></div>
                      </div>
                    </div>
                  )}
                </td>
                <td className="p-4">
                  <button className="text-xs font-semibold px-3 py-1.5 rounded bg-white/10 hover:bg-white/20 transition">Manage</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

    </div>
  );
}
