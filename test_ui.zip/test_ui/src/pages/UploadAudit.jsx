import { useState } from 'react';
import { UploadCloud, File, CheckCircle2, AlertCircle, X, ChevronDown, Activity } from 'lucide-react';

export default function UploadAudit() {
  const [isUploading, setIsUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [showResults, setShowResults] = useState(false);

  const handleUpload = () => {
    setIsUploading(true);
    // Simulate upload and LLM processing
    let prog = 0;
    const interval = setInterval(() => {
      prog += 5;
      setProgress(prog);
      if (prog >= 100) {
        clearInterval(interval);
        setTimeout(() => {
          setIsUploading(false);
          setShowResults(true);
        }, 500);
      }
    }, 150);
  };

  return (
    <div className="animate-fade-in">
      {!showResults ? (
        <div className="grid grid-cols-2 gap-8">
          {/* Upload Configuration */}
          <div className="glass-panel p-6 flex flex-col gap-6">
            <div>
              <h2 className="text-xl mb-2">Configure Upload Context</h2>
              <p className="text-muted text-sm">Select the hierarchical category for these recordings or transcripts.</p>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="flex flex-col gap-2">
                <label className="text-sm font-medium">IMU</label>
                <select className="select w-full">
                  <option>Select IMU</option>
                  <option>Sales</option>
                  <option>Technical Support</option>
                  <option>Customer Service</option>
                </select>
              </div>
              <div className="flex flex-col gap-2">
                <label className="text-sm font-medium">Client</label>
                <select className="select w-full">
                  <option>Select Client</option>
                  <option>Acme Corp</option>
                  <option>Globex</option>
                </select>
              </div>
              <div className="flex flex-col gap-2">
                <label className="text-sm font-medium">Process</label>
                <select className="select w-full">
                  <option>Select Process</option>
                  <option>Onboarding</option>
                  <option>Troubleshooting</option>
                  <option>Billing</option>
                </select>
              </div>
              <div className="flex flex-col gap-2">
                <label className="text-sm font-medium">Geo</label>
                <select className="select w-full">
                  <option>Select Geo</option>
                  <option>North America</option>
                  <option>EMEA</option>
                  <option>APAC</option>
                </select>
              </div>
            </div>
          </div>

          {/* Upload Zone */}
          <div className="glass-panel p-6 flex flex-col justify-center items-center text-center relative" style={{ minHeight: '300px', borderStyle: 'dashed', borderWidth: '2px' }}>
            {isUploading ? (
              <div className="w-full max-w-xs flex flex-col items-center">
                <Activity className="text-primary mb-4 animate-pulse" size={48} />
                <h3 className="text-lg font-medium mb-4">LLM Engine Processing...</h3>
                <div className="progress-bg w-full">
                  <div className="progress-fill" style={{ width: `${progress}%` }}></div>
                </div>
                <div className="text-sm text-muted mt-2">{progress}% Complete</div>
              </div>
            ) : (
              <>
                <div style={{ background: 'rgba(139, 92, 246, 0.1)', padding: '1.5rem', borderRadius: '50%', marginBottom: '1.5rem' }}>
                  <UploadCloud size={48} className="text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Drag & Drop Files Here</h3>
                <p className="text-muted text-sm mb-6 max-w-sm">Upload interaction transcripts (.txt, .json) or call recordings (.mp3, .wav) for automated LLM auditing.</p>
                <button className="btn btn-primary" onClick={handleUpload}>
                  Browse Files
                </button>
              </>
            )}
          </div>
        </div>
      ) : (
        /* Results View */
        <div className="animate-fade-in flex flex-col gap-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-2xl font-bold mb-1">Audit Results</h2>
              <p className="text-muted">Batch #B-99824 • Tech Support / Acme Corp / Troubleshooting / NA</p>
            </div>
            <button className="btn btn-secondary" onClick={() => { setShowResults(false); setProgress(0); }}>Upload New Batch</button>
          </div>

          <div className="grid grid-cols-3 gap-6">
            {/* Interaction Card 1 */}
            <div className="glass-panel p-6 flex flex-col gap-4 relative overflow-hidden">
              <div style={{ position: 'absolute', top: 0, left: 0, width: '4px', height: '100%', background: 'var(--success)' }}></div>
              <div className="flex justify-between items-start">
                <div>
                  <div className="text-sm text-muted mb-1">Interaction ID: INT-1002</div>
                  <div className="font-semibold text-lg">Agent: Alex Chen</div>
                </div>
                <span className="badge badge-success flex gap-1"><CheckCircle2 size={12} /> Low Risk</span>
              </div>
              
              <div className="grid grid-cols-2 gap-y-4 gap-x-2 mt-2">
                <div>
                  <div className="text-xs text-muted mb-1">NPS Score</div>
                  <div className="font-bold text-success text-xl">9.5</div>
                </div>
                <div>
                  <div className="text-xs text-muted mb-1">AI Confidence</div>
                  <div className="font-bold text-xl">98%</div>
                </div>
                <div>
                  <div className="text-xs text-muted mb-1">Resolution</div>
                  <div className="font-medium">Resolved</div>
                </div>
                <div>
                  <div className="text-xs text-muted mb-1">Sentiment</div>
                  <div className="font-medium text-success">Positive</div>
                </div>
              </div>

              <div className="mt-2 pt-4 border-t" style={{ borderColor: 'var(--border-color)' }}>
                <div className="text-xs text-muted mb-2">Key Highlights</div>
                <div className="text-sm bg-[#10b98120] p-2 rounded text-[#10b981] mb-2 border border-[#10b98140]">
                  "Agent showed excellent empathy and resolved the billing issue immediately."
                </div>
                <button className="btn btn-secondary w-full text-xs mt-2">View Full Transcript & Audit</button>
              </div>
            </div>

            {/* Interaction Card 2 */}
            <div className="glass-panel p-6 flex flex-col gap-4 relative overflow-hidden">
              <div style={{ position: 'absolute', top: 0, left: 0, width: '4px', height: '100%', background: 'var(--danger)' }}></div>
              <div className="flex justify-between items-start">
                <div>
                  <div className="text-sm text-muted mb-1">Interaction ID: INT-1003</div>
                  <div className="font-semibold text-lg">Agent: Sarah Jenkins</div>
                </div>
                <span className="badge badge-danger flex gap-1"><AlertCircle size={12} /> High Risk</span>
              </div>
              
              <div className="grid grid-cols-2 gap-y-4 gap-x-2 mt-2">
                <div>
                  <div className="text-xs text-muted mb-1">NPS Score</div>
                  <div className="font-bold text-danger text-xl">3.0</div>
                </div>
                <div>
                  <div className="text-xs text-muted mb-1">AI Confidence</div>
                  <div className="font-bold text-xl">95%</div>
                </div>
                <div>
                  <div className="text-xs text-muted mb-1">Resolution</div>
                  <div className="font-medium text-danger">Unresolved</div>
                </div>
                <div>
                  <div className="text-xs text-muted mb-1">Sentiment</div>
                  <div className="font-medium text-danger">Frustrated</div>
                </div>
              </div>

              <div className="mt-2 pt-4 border-t" style={{ borderColor: 'var(--border-color)' }}>
                <div className="text-xs text-muted mb-2">Identified Gaps</div>
                <div className="flex flex-wrap gap-2 mb-2">
                  <span className="badge badge-warning text-xs">Missed Verification</span>
                  <span className="badge badge-danger text-xs">Escalation Escalated</span>
                </div>
                <button className="btn btn-secondary w-full text-xs mt-2">View Full Transcript & Audit</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
