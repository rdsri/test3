import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, ReferenceLine } from 'recharts';
import { Download, Calendar, TrendingUp } from 'lucide-react';

const improvementData = [
  { week: 'W1 (Pre)', score: 4.5, target: 8.0 },
  { week: 'W2 (Pre)', score: 4.2, target: 8.0 },
  { week: 'W3 (Training)', score: 5.8, target: 8.0 },
  { week: 'W4 (Post)', score: 7.5, target: 8.0 },
  { week: 'W5 (Post)', score: 8.2, target: 8.0 },
  { week: 'W6 (Post)', score: 8.6, target: 8.0 },
];

export default function Reports() {
  return (
    <div className="animate-fade-in flex flex-col gap-6">
      
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Training ROI & Comparisons</h1>
          <p className="text-muted">Analyze the performance impact of assigned courses over time.</p>
        </div>
        <div className="flex gap-3">
          <button className="btn btn-secondary"><Calendar size={16} /> Last 90 Days</button>
          <button className="btn btn-primary"><Download size={16} /> Export PDF Report</button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Comparison Chart */}
        <div className="glass-panel p-6 col-span-2">
          <h2 className="text-lg font-semibold mb-1">Pre vs Post Course Performance</h2>
          <p className="text-sm text-muted mb-6">Cohort: "Resolution Training Q1" (84 Agents)</p>
          
          <div className="w-full h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={improvementData} margin={{ left: -20, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" vertical={false} />
                <XAxis dataKey="week" stroke="var(--text-muted)" fontSize={12} tickMargin={15} tickLine={false} axisLine={false} />
                <YAxis stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} domain={[0, 10]} />
                <Tooltip 
                  cursor={{ stroke: 'var(--border-color)', strokeWidth: 1 }}
                  contentStyle={{ background: 'var(--bg-surface-hover)', border: '1px solid var(--border-color)', borderRadius: '8px' }} 
                />
                <ReferenceLine x="W3 (Training)" stroke="var(--warning)" strokeDasharray="3 3" label={{ position: 'top', value: 'Course Start', fill: 'var(--warning)', fontSize: 12, dy: -10 }} />
                <Line type="monotone" dataKey="score" name="Cohort Average NPS" stroke="var(--primary)" strokeWidth={4} dot={{ r: 6, fill: 'var(--bg-color)', strokeWidth: 2 }} activeDot={{ r: 8 }} />
                <Line type="monotone" dataKey="target" name="Target Benchmark" stroke="var(--success)" strokeWidth={2} strokeDasharray="5 5" dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Metrics impact */}
        <div className="flex flex-col gap-6">
          <div className="glass-panel p-6">
            <h3 className="text-md font-medium text-muted mb-4 uppercase tracking-wider text-xs">Key Improvements</h3>
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <div>
                  <div className="font-semibold text-lg">NPS Score</div>
                  <div className="text-xs text-muted">Pre: 4.35 → Post: 8.43</div>
                </div>
                <div className="flex items-center gap-1 text-success font-bold text-xl">
                  <TrendingUp size={20} /> +93%
                </div>
              </div>
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <div>
                  <div className="font-semibold text-lg">Resolution Rate</div>
                  <div className="text-xs text-muted">Pre: 62% → Post: 89%</div>
                </div>
                <div className="flex items-center gap-1 text-success font-bold text-xl">
                  <TrendingUp size={20} /> +43%
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-semibold text-lg">Compliance Failures</div>
                  <div className="text-xs text-muted">Pre: 18/100 → Post: 2/100</div>
                </div>
                <div className="flex items-center gap-1 text-success font-bold text-xl">
                  <TrendingUp className="rotate-180" size={20} /> -88%
                </div>
              </div>
            </div>
          </div>
          
          <button className="btn btn-primary w-full shadow-lg hover:-translate-y-1 transition-transform flex justify-center py-4 text-base">
            Generate Executive Summary
          </button>
        </div>
      </div>
    </div>
  );
}
