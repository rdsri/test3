import { useState } from 'react';
import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, ReferenceLine, Cell
} from 'recharts';
import {
  ShieldPlus, CheckCircle2, Clock, AlertCircle, XCircle, ChevronDown,
  ChevronUp, User, BookOpen, Calendar, TrendingUp, TrendingDown,
  ArrowRight, Activity, Target, Zap, BarChart2, ClipboardList
} from 'lucide-react';
import './CAPA.css';

/* ─────────────── DATA ─────────────── */
const CAPA_ITEMS = [
  {
    id: 'capa-1',
    rcaTitle: 'Critically Low NPS Score',
    group: 'Tech Support · Hooli · Tech Setup · LATAM',
    category: 'NPS Score',
    severity: 'critical',
    assignedTo: 'Maria Santos',
    team: 'LATAM L1 Team',
    action: 'Advanced Technical Troubleshooting Skills',
    actionType: 'course',
    status: 'in-progress',
    progress: 65,
    startDate: '2026-02-10',
    targetDate: '2026-03-20',
    before: { nps: 3.9, compliance: 61, resolution: 55, risk: 34 },
    after:  { nps: 6.1, compliance: 74, resolution: 72, risk: 20 },
    timeline: [
      { date: '2026-02-10', event: 'CAPA Created', type: 'created' },
      { date: '2026-02-12', event: 'Assigned to Maria Santos', type: 'assigned' },
      { date: '2026-02-18', event: 'Course enrollment confirmed', type: 'progress' },
      { date: '2026-03-01', event: 'Module 1 & 2 completed (40%)', type: 'progress' },
      { date: '2026-03-08', event: 'Mid-point assessment passed', type: 'milestone' },
    ],
    trend: [
      { week: 'W1 (Pre)', nps: 3.9 }, { week: 'W2 (Pre)', nps: 4.1 },
      { week: 'W3', nps: 4.8 }, { week: 'W4', nps: 5.4 },
      { week: 'W5 (Now)', nps: 6.1 },
    ],
  },
  {
    id: 'capa-2',
    rcaTitle: 'Elevated Risk Rate (34%)',
    group: 'Tech Support · Hooli · Tech Setup · LATAM',
    category: 'Risk Rate',
    severity: 'critical',
    assignedTo: 'Carlos Mendez',
    team: 'LATAM Compliance Unit',
    action: 'Risk Identification & Mitigation in Support Calls',
    actionType: 'course',
    status: 'completed',
    progress: 100,
    startDate: '2026-01-20',
    targetDate: '2026-02-28',
    before: { nps: 3.9, compliance: 61, resolution: 55, risk: 34 },
    after:  { nps: 7.2, compliance: 85, resolution: 80, risk: 10 },
    timeline: [
      { date: '2026-01-20', event: 'CAPA Initiated — Risk critical', type: 'created' },
      { date: '2026-01-22', event: 'Carlos Mendez assigned as owner', type: 'assigned' },
      { date: '2026-01-28', event: 'Team briefing & kick-off session', type: 'progress' },
      { date: '2026-02-10', event: 'Course completed — 100%', type: 'milestone' },
      { date: '2026-02-28', event: 'Post-assessment: Risk dropped to 10%', type: 'completed' },
    ],
    trend: [
      { week: 'W1 (Pre)', nps: 3.9 }, { week: 'W2 (Pre)', nps: 4.3 },
      { week: 'W3', nps: 5.2 }, { week: 'W4', nps: 6.5 },
      { week: 'W5 (Post)', nps: 7.2 },
    ],
  },
  {
    id: 'capa-3',
    rcaTitle: 'High Escalation Rate (19%)',
    group: 'Customer Service · Globex · Billing · EMEA',
    category: 'Escalation Rate',
    severity: 'high',
    assignedTo: 'Sophie Müller',
    team: 'EMEA Billing Squad',
    action: 'Billing Dispute Resolution Mastery',
    actionType: 'course',
    status: 'in-progress',
    progress: 38,
    startDate: '2026-02-25',
    targetDate: '2026-04-05',
    before: { nps: 5.1, compliance: 69, resolution: 63, risk: 28 },
    after:  { nps: 5.8, compliance: 74, resolution: 70, risk: 22 },
    timeline: [
      { date: '2026-02-25', event: 'CAPA Raised by QA Manager', type: 'created' },
      { date: '2026-02-26', event: 'Assigned to Sophie Müller & team', type: 'assigned' },
      { date: '2026-03-05', event: 'Module 1 completed (15%)', type: 'progress' },
    ],
    trend: [
      { week: 'W1 (Pre)', nps: 5.1 }, { week: 'W2 (Pre)', nps: 5.0 },
      { week: 'W3', nps: 5.4 }, { week: 'W4 (Now)', nps: 5.8 },
    ],
  },
  {
    id: 'capa-4',
    rcaTitle: 'Compliance Adherence Below Benchmark',
    group: 'Sales · Globex · Onboarding · EMEA',
    category: 'Compliance',
    severity: 'high',
    assignedTo: 'James O\'Brien',
    team: 'EMEA Compliance Team',
    action: 'Regulatory Compliance in Customer Service',
    actionType: 'course',
    status: 'not-started',
    progress: 0,
    startDate: '2026-03-15',
    targetDate: '2026-04-20',
    before: { nps: 5.8, compliance: 78, resolution: 72, risk: 22 },
    after:  null,
    timeline: [
      { date: '2026-03-13', event: 'CAPA Created from RCA findings', type: 'created' },
      { date: '2026-03-15', event: 'Scheduled start date', type: 'assigned' },
    ],
    trend: [
      { week: 'W1', nps: 5.8 }, { week: 'W2', nps: 5.6 },
      { week: 'W3', nps: 5.5 }, { week: 'W4 (Now)', nps: 5.8 },
    ],
  },
];

/* ─────────────── HELPERS ─────────────── */
const STATUS_MAP = {
  'completed':   { label: 'Completed',   color: 'var(--success)', bg: 'rgba(16,185,129,0.12)',  icon: <CheckCircle2 size={13}/> },
  'in-progress': { label: 'In Progress', color: 'var(--primary)', bg: 'rgba(139,92,246,0.12)', icon: <Clock size={13}/> },
  'not-started': { label: 'Not Started', color: 'var(--text-muted)', bg: 'rgba(255,255,255,0.06)', icon: <AlertCircle size={13}/> },
};

const SEVERITY_MAP = {
  critical: { color: '#f43f5e', label: 'Critical' },
  high:     { color: '#f97316', label: 'High' },
  medium:   { color: '#f59e0b', label: 'Medium' },
};

const TIMELINE_ICONS = {
  created:   { icon: <ShieldPlus size={13}/>,   color: '#8b5cf6' },
  assigned:  { icon: <User size={13}/>,          color: '#0ea5e9' },
  progress:  { icon: <Activity size={13}/>,      color: '#f59e0b' },
  milestone: { icon: <Target size={13}/>,        color: '#10b981' },
  completed: { icon: <CheckCircle2 size={13}/>,  color: '#10b981' },
};

function impPct(before, after, key) {
  if (!after) return null;
  const inv = key === 'risk';
  const delta = after[key] - before[key];
  return inv ? -delta : delta;
}

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: 'rgba(10,12,28,0.97)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, padding: '0.5rem 0.875rem', fontSize: '0.78rem' }}>
      <p style={{ color: 'var(--text-muted)', marginBottom: 4 }}>{label}</p>
      {payload.map((p, i) => <p key={i} style={{ color: p.color, fontWeight: 700 }}>{p.name}: {p.value}</p>)}
    </div>
  );
}

/* ─────────────── SUMMARY BAR ─────────────── */
function SummaryBar({ items }) {
  const total     = items.length;
  const done      = items.filter(i => i.status === 'completed').length;
  const inProg    = items.filter(i => i.status === 'in-progress').length;
  const notStart  = items.filter(i => i.status === 'not-started').length;
  const avgImp    = items.filter(i => i.after).reduce((a, i) => a + (i.after.nps - i.before.nps), 0) / (items.filter(i => i.after).length || 1);

  return (
    <div className="capa-summary-bar">
      {[
        { label: 'Total CAPAs', value: total,               color: 'var(--primary)',  icon: <ClipboardList size={20}/> },
        { label: 'Completed',   value: done,                color: 'var(--success)',  icon: <CheckCircle2 size={20}/> },
        { label: 'In Progress', value: inProg,              color: '#a78bfa',         icon: <Activity size={20}/> },
        { label: 'Not Started', value: notStart,            color: 'var(--text-muted)', icon: <AlertCircle size={20}/> },
        { label: 'Avg NPS Lift', value: `+${avgImp.toFixed(1)}`, color: 'var(--success)', icon: <TrendingUp size={20}/> },
      ].map((s, i) => (
        <div key={i} className="capa-summary-chip glass-panel">
          <div className="capa-sum-icon" style={{ color: s.color, background: `${s.color}18` }}>{s.icon}</div>
          <div>
            <div className="capa-sum-value" style={{ color: s.color }}>{s.value}</div>
            <div className="capa-sum-label">{s.label}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ─────────────── BEFORE / AFTER CHART ─────────────── */
function BeforeAfterChart({ item }) {
  const metrics = ['nps', 'compliance', 'resolution', 'risk'];
  const labels  = { nps: 'NPS', compliance: 'Compliance', resolution: 'Resolution', risk: 'Risk Rate' };

  const barData = metrics.map(m => ({
    name: labels[m],
    Before: item.before[m],
    After:  item.after ? item.after[m] : null,
    isInverted: m === 'risk',
  }));

  return (
    <div className="ba-chart-wrap">
      <div className="ba-chart-title">Before vs After — {item.rcaTitle}</div>
      <div style={{ height: 200 }}>
        <ResponsiveContainer>
          <BarChart data={barData} margin={{ left: -20 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" vertical={false} />
            <XAxis dataKey="name" stroke="var(--text-muted)" fontSize={11} tickLine={false} axisLine={false} />
            <YAxis stroke="var(--text-muted)" fontSize={11} tickLine={false} axisLine={false} />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="Before" name="Before" fill="rgba(244,63,94,0.7)" radius={[3,3,0,0]} barSize={22} />
            {item.after && <Bar dataKey="After" name="After" fill="rgba(16,185,129,0.8)" radius={[3,3,0,0]} barSize={22} />}
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* KPI improvement chips */}
      {item.after && (
        <div className="kpi-row">
          {metrics.map(m => {
            const imp = impPct(item.before, item.after, m);
            const good = imp > 0;
            return (
              <div key={m} className="kpi-chip" style={{ borderColor: good ? 'rgba(16,185,129,0.3)' : 'rgba(244,63,94,0.3)' }}>
                <span className="kpi-label">{labels[m]}</span>
                <span className="kpi-delta" style={{ color: good ? 'var(--success)' : 'var(--danger)' }}>
                  {good ? <TrendingUp size={12}/> : <TrendingDown size={12}/>}
                  {good ? '+' : ''}{((imp / item.before[m]) * 100).toFixed(0)}%
                </span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ─────────────── TREND SPARKLINE ─────────────── */
function TrendSparkline({ trend, status }) {
  return (
    <div style={{ height: 80 }}>
      <ResponsiveContainer>
        <LineChart data={trend} margin={{ top: 5, right: 5, left: -30, bottom: 0 }}>
          <Line
            type="monotone" dataKey="nps" name="NPS"
            stroke={status === 'completed' ? 'var(--success)' : status === 'in-progress' ? 'var(--primary)' : 'var(--text-muted)'}
            strokeWidth={2.5}
            dot={{ r: 3 }}
          />
          <Tooltip content={<CustomTooltip />} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

/* ─────────────── TIMELINE ─────────────── */
function Timeline({ events }) {
  return (
    <div className="timeline-wrap">
      {events.map((e, i) => {
        const cfg = TIMELINE_ICONS[e.type] || TIMELINE_ICONS.progress;
        return (
          <div key={i} className="timeline-item">
            <div className="timeline-dot" style={{ color: cfg.color, background: `${cfg.color}18`, border: `1px solid ${cfg.color}40` }}>
              {cfg.icon}
            </div>
            {i < events.length - 1 && <div className="timeline-line" />}
            <div className="timeline-content">
              <span className="timeline-event">{e.event}</span>
              <span className="timeline-date">{e.date}</span>
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* ─────────────── CAPA CARD ─────────────── */
function CAPACard({ item }) {
  const [expanded, setExpanded] = useState(false);
  const st  = STATUS_MAP[item.status];
  const sev = SEVERITY_MAP[item.severity];
  const daysLeft = Math.ceil((new Date(item.targetDate) - new Date()) / 86400000);

  return (
    <div className={`capa-card glass-panel ${expanded ? 'expanded' : ''}`}>
      {/* Left severity stripe */}
      <div className="capa-stripe" style={{ background: sev.color }} />

      {/* ── Card Header (always visible) ── */}
      <div className="capa-card-main" onClick={() => setExpanded(e => !e)}>
        {/* Top row */}
        <div className="capa-card-top">
          <div className="capa-card-id-block">
            <div className="capa-id">{item.id.toUpperCase()}</div>
            <span className="capa-sev" style={{ color: sev.color, background: `${sev.color}18` }}>
              {sev.label}
            </span>
          </div>
          <div className="capa-card-status">
            <span className="capa-status-badge" style={{ color: st.color, background: st.bg }}>
              {st.icon} {st.label}
            </span>
            {expanded ? <ChevronUp size={16} className="text-muted" /> : <ChevronDown size={16} className="text-muted" />}
          </div>
        </div>

        {/* Title + group */}
        <h3 className="capa-card-title">{item.rcaTitle}</h3>
        <p className="capa-card-group">{item.group}</p>

        {/* Meta row */}
        <div className="capa-meta-row">
          <div className="capa-meta-item">
            <User size={13} />
            <span>{item.assignedTo}</span>
            <span className="capa-meta-sub">· {item.team}</span>
          </div>
          <div className="capa-meta-item">
            <BookOpen size={13} />
            <span className="capa-action-name">{item.action}</span>
          </div>
          <div className="capa-meta-item">
            <Calendar size={13} />
            <span>Target: {item.targetDate}</span>
            {item.status !== 'completed' && (
              <span className={`capa-days ${daysLeft < 7 ? 'urgent' : ''}`}>
                {daysLeft > 0 ? `${daysLeft}d left` : `${Math.abs(daysLeft)}d overdue`}
              </span>
            )}
          </div>
        </div>

        {/* Progress bar */}
        <div className="capa-progress-row">
          <div style={{ flex: 1 }}>
            <div className="progress-bg">
              <div
                className="progress-fill"
                style={{
                  width: `${item.progress}%`,
                  background: item.status === 'completed'
                    ? 'var(--success)'
                    : `linear-gradient(90deg, var(--primary), var(--secondary))`,
                }}
              />
            </div>
          </div>
          <span style={{ fontSize: '0.8rem', fontWeight: 700, minWidth: 36, textAlign: 'right',
            color: item.status === 'completed' ? 'var(--success)' : 'var(--primary)' }}>
            {item.progress}%
          </span>
        </div>

        {/* NPS Trend sparkline */}
        <TrendSparkline trend={item.trend} status={item.status} />
      </div>

      {/* ── Expanded Section ── */}
      {expanded && (
        <div className="capa-expanded-body">
          <div className="capa-exp-grid">
            {/* Timeline */}
            <div className="capa-exp-section">
              <div className="capa-exp-title"><ClipboardList size={15}/> Activity Timeline</div>
              <Timeline events={item.timeline} />
            </div>

            {/* Before / After */}
            <div className="capa-exp-section">
              <div className="capa-exp-title"><BarChart2 size={15}/> Performance Comparison</div>
              {item.after
                ? <BeforeAfterChart item={item} />
                : (
                  <div className="capa-no-after">
                    <Activity size={28} style={{ opacity: 0.4 }} />
                    <span>Post-course data will appear here once the CAPA is completed.</span>
                  </div>
                )
              }
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ─────────────── AGGREGATE BEFORE/AFTER ─────────────── */
function AggregateImpactChart({ items }) {
  const completed = items.filter(i => i.after);
  const data = [
    { name: 'NPS Score',    Before: +(completed.reduce((a,i)=>a+i.before.nps,0)/completed.length).toFixed(1), After: +(completed.reduce((a,i)=>a+i.after.nps,0)/completed.length).toFixed(1) },
    { name: 'Compliance',   Before: Math.round(completed.reduce((a,i)=>a+i.before.compliance,0)/completed.length), After: Math.round(completed.reduce((a,i)=>a+i.after.compliance,0)/completed.length) },
    { name: 'Resolution',   Before: Math.round(completed.reduce((a,i)=>a+i.before.resolution,0)/completed.length), After: Math.round(completed.reduce((a,i)=>a+i.after.resolution,0)/completed.length) },
    { name: 'Risk Rate',    Before: Math.round(completed.reduce((a,i)=>a+i.before.risk,0)/completed.length),       After: Math.round(completed.reduce((a,i)=>a+i.after.risk,0)/completed.length) },
  ];

  return (
    <div className="capa-card glass-panel" style={{ padding: '1.5rem' }}>
      <div className="capa-agg-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontWeight: 700, fontSize: '0.9375rem' }}>
          <Zap size={17} style={{ color: 'var(--primary)' }} /> Aggregate Impact: All Completed CAPAs
        </div>
        <div style={{ display: 'flex', gap: 16, fontSize: '0.75rem', alignItems: 'center' }}>
          <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}><span style={{ width: 10, height: 10, borderRadius: 2, background: 'rgba(244,63,94,0.7)', display: 'inline-block' }}></span>Before</span>
          <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}><span style={{ width: 10, height: 10, borderRadius: 2, background: 'rgba(16,185,129,0.8)', display: 'inline-block' }}></span>After</span>
        </div>
      </div>
      <div style={{ height: 220, marginTop: '1rem' }}>
        <ResponsiveContainer>
          <BarChart data={data} margin={{ left: -10, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" vertical={false} />
            <XAxis dataKey="name" stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} />
            <YAxis stroke="var(--text-muted)" fontSize={11} tickLine={false} axisLine={false} />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="Before" name="Before" fill="rgba(244,63,94,0.65)" radius={[4,4,0,0]} barSize={28} />
            <Bar dataKey="After"  name="After"  fill="rgba(16,185,129,0.8)" radius={[4,4,0,0]} barSize={28} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Global KPIs */}
      <div className="global-kpi-row">
        {[
          { label: 'NPS Improvement', icon: <TrendingUp size={18}/>, value: '+2.5 pts', color: 'var(--success)' },
          { label: 'Compliance Gain', icon: <TrendingUp size={18}/>, value: '+18%',     color: 'var(--success)' },
          { label: 'Risk Reduction',  icon: <TrendingDown size={18}/>, value: '-16%',   color: '#34d399' },
          { label: 'Open CAPAs',      icon: <Clock size={18}/>,        value: '2',      color: 'var(--warning)' },
        ].map((k, i) => (
          <div key={i} className="global-kpi-chip" style={{ borderColor: `${k.color}30` }}>
            <div style={{ color: k.color, marginBottom: 4 }}>{k.icon}</div>
            <div style={{ fontSize: '1.3rem', fontWeight: 800, color: k.color }}>{k.value}</div>
            <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: 500, marginTop: 2 }}>{k.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ─────────────── MAIN PAGE ─────────────── */
export default function CAPA() {
  const [filter, setFilter] = useState('all');

  const filtered = CAPA_ITEMS.filter(i => {
    if (filter === 'completed')   return i.status === 'completed';
    if (filter === 'in-progress') return i.status === 'in-progress';
    if (filter === 'not-started') return i.status === 'not-started';
    return true;
  });

  return (
    <div className="capa-root animate-fade-in">
      {/* Page intro */}
      <div className="capa-page-intro">
        <div>
          <h1 className="text-2xl">Corrective & Preventive Actions</h1>
          <p className="text-muted" style={{ marginTop: 4, fontSize: '0.875rem' }}>
            Track RCA action assignments, monitor progress, and measure post-training performance impact
          </p>
        </div>
        <div className="filter-tabs">
          {[
            { value: 'all',          label: 'All CAPAs' },
            { value: 'completed',    label: '✓ Completed' },
            { value: 'in-progress',  label: '⏳ In Progress' },
            { value: 'not-started',  label: '○ Not Started' },
          ].map(f => (
            <button
              key={f.value}
              className={`filter-tab ${filter === f.value ? 'active' : ''}`}
              onClick={() => setFilter(f.value)}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Summary Stats */}
      <SummaryBar items={CAPA_ITEMS} />

      {/* Aggregate Impact (show only when 'all' or 'completed') */}
      {(filter === 'all' || filter === 'completed') && (
        <AggregateImpactChart items={CAPA_ITEMS} />
      )}

      {/* CAPA Cards */}
      <div className="capa-list">
        {filtered.map(item => (
          <CAPACard key={item.id} item={item} />
        ))}
      </div>
    </div>
  );
}
