import { useState } from 'react';
import {
  LineChart, Line, BarChart, Bar, ScatterChart, Scatter,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  ReferenceLine, Cell
} from 'recharts';
import {
  AlertTriangle, TrendingDown, TrendingUp, Globe2,
  Target, Link2, BarChart2, Activity, ChevronDown,
  ChevronUp, Brain, Lightbulb, ArrowDown, ArrowUp, Minus
} from 'lucide-react';
import './RCAAnalysis.css';

/* ─────────────── DATA ─────────────── */

// "Bad" items from Analytics (health < 60 or specific category failures)
const GEO_DATA = {
  LATAM: {
    geo: 'LATAM',
    group: 'Tech Support · Hooli · Tech Setup',
    health: 44,
    badCategories: ['NPS Score', 'AI Score', 'Resolution Rate', 'Compliance', 'Positive Sentiment', 'CAST Score', 'Risk Rate', 'Escalation Rate'],
    reasons: [
      { id: 'r1', type: 'critical', icon: '🧠', title: 'Insufficient Product Knowledge', detail: 'Agents lack deep understanding of Hooli\'s tech setup procedures. LLM analysis flagged 68% of calls with incorrect technical guidance, directly impacting NPS (3.9) and Risk Rate (34%).' },
      { id: 'r2', type: 'critical', icon: '📋', title: 'Non-Compliance with Call Scripts', detail: 'Only 61% compliance rate observed. Agents skip mandatory disclosure and verification steps in 3 out of 5 calls, creating both regulatory and reputational risk.' },
      { id: 'r3', type: 'high', icon: '🎭', title: 'Lack of Empathy & Soft Skills', detail: 'Sentiment analysis reveals robotic, scripted tone in 58% of interactions. Customers report feeling unheard, driving escalation rates up to 28%.' },
      { id: 'r4', type: 'high', icon: '⏱️', title: 'Extended Resolution Times', detail: 'Average handle time is 340s — significantly above the 210s benchmark. Complex setups are handled without proper escalation paths, causing customer frustration.' },
      { id: 'r5', type: 'medium', icon: '📉', title: 'Poor CAST Score Structure', detail: 'Agents consistently miss the opening rapport stage and closing confirmation phase. CAST score at 48% reflects structural deficiencies in call management.' },
    ],
    correlations: [
      { factor: 'Knowledge Gap', npsImpact: -4.2, riskImpact: 28, strength: 'Very Strong' },
      { factor: 'Script Deviation', npsImpact: -2.8, riskImpact: 18, strength: 'Strong' },
      { factor: 'Escalation Freq.', npsImpact: -3.1, riskImpact: 22, strength: 'Strong' },
      { factor: 'Handle Time',     npsImpact: -1.5, riskImpact: 9,  strength: 'Moderate' },
      { factor: 'Sentiment Score', npsImpact: -2.2, riskImpact: 14, strength: 'Strong' },
    ],
    topBottom: {
      metric: 'NPS Score',
      top:    [{ name: 'APAC',          val: 7.2 }, { name: 'N. America',    val: 8.9 }, { name: 'EMEA',         val: 5.8 }],
      bottom: [{ name: 'LATAM',         val: 3.9 }, { name: 'EMEA·Billing',  val: 5.1 }, { name: 'EMEA·OnBoard', val: 5.8 }],
    },
    trend: [
      { week: 'W1', nps: 4.8, compliance: 66, risk: 28 },
      { week: 'W2', nps: 4.5, compliance: 63, risk: 30 },
      { week: 'W3', nps: 4.1, compliance: 62, risk: 32 },
      { week: 'W4', nps: 3.9, compliance: 61, risk: 34 },
      { week: 'W5', nps: 3.7, compliance: 59, risk: 36 },
    ],
    scatter: [
      { x: 10, y: 3.5, label: 'Agent A' }, { x: 25, y: 4.2, label: 'Agent B' },
      { x: 40, y: 5.8, label: 'Agent C' }, { x: 55, y: 6.1, label: 'Agent D' },
      { x: 70, y: 7.0, label: 'Agent E' }, { x: 85, y: 8.2, label: 'Agent F' },
      { x: 15, y: 3.9, label: 'Agent G' }, { x: 32, y: 4.5, label: 'Agent H' },
    ],
  },
  EMEA: {
    geo: 'EMEA',
    group: 'Sales · Globex · Onboarding  |  Customer Svc · Globex · Billing',
    health: 58,
    badCategories: ['Resolution Rate', 'Compliance', 'Positive Sentiment', 'CAST Score', 'Risk Rate', 'Escalation Rate'],
    reasons: [
      { id: 'r1', type: 'critical', icon: '🚨', title: 'High Escalation Rate (avg 18%)', detail: 'Agents across EMEA are escalating nearly 1 in 5 calls to supervisors. Root cause linked to insufficient billing system access & dispute resolution authority.' },
      { id: 'r2', type: 'high', icon: '📋', title: 'Compliance Shortfalls', detail: 'GDPR-related consent failures observed in 22% of billing interactions. Agents are not following post-call documentation protocols.' },
      { id: 'r3', type: 'medium', icon: '🗣️', title: 'Language & Cultural Communication Gaps', detail: 'Multilingual customer base in EMEA region creates gaps in nuanced de-escalation. Sentiment scores show frustration peaks in non-English interactions.' },
    ],
    correlations: [
      { factor: 'Billing Authority', npsImpact: -3.0, riskImpact: 20, strength: 'Very Strong' },
      { factor: 'GDPR Compliance', npsImpact: -1.8, riskImpact: 15, strength: 'Strong' },
      { factor: 'Language Barrier', npsImpact: -1.2, riskImpact: 8,  strength: 'Moderate' },
    ],
    topBottom: {
      metric: 'NPS Score',
      top:    [{ name: 'N. America', val: 8.9 }, { name: 'APAC', val: 7.2 }, { name: 'EMEA·Sales', val: 5.8 }],
      bottom: [{ name: 'LATAM',      val: 3.9 }, { name: 'EMEA·Billing', val: 5.1 }, { name: 'EMEA·OnBoard', val: 5.8 }],
    },
    trend: [
      { week: 'W1', nps: 6.5, compliance: 82, risk: 15 },
      { week: 'W2', nps: 6.2, compliance: 80, risk: 17 },
      { week: 'W3', nps: 5.9, compliance: 79, risk: 18 },
      { week: 'W4', nps: 5.8, compliance: 78, risk: 19 },
      { week: 'W5', nps: 5.5, compliance: 76, risk: 21 },
    ],
    scatter: [
      { x: 20, y: 4.8, label: 'Agent A' }, { x: 38, y: 5.5, label: 'Agent B' },
      { x: 52, y: 6.2, label: 'Agent C' }, { x: 65, y: 6.8, label: 'Agent D' },
      { x: 78, y: 7.5, label: 'Agent E' }, { x: 90, y: 8.1, label: 'Agent F' },
    ],
  },
};

const GEO_OPTIONS = ['LATAM', 'EMEA'];

/* ─────────── HELPERS ─────────── */
const REASON_CONFIG = {
  critical: { label: 'Critical', color: '#f43f5e', bg: 'rgba(244,63,94,0.1)', border: 'rgba(244,63,94,0.25)' },
  high:     { label: 'High',     color: '#f97316', bg: 'rgba(249,115,22,0.1)', border: 'rgba(249,115,22,0.25)' },
  medium:   { label: 'Medium',   color: '#f59e0b', bg: 'rgba(245,158,11,0.1)', border: 'rgba(245,158,11,0.2)' },
};

const CORR_STRENGTH = {
  'Very Strong': { color: '#f43f5e', w: '95%' },
  'Strong':      { color: '#f97316', w: '72%' },
  'Moderate':    { color: '#f59e0b', w: '50%' },
  'Weak':        { color: '#10b981', w: '28%' },
};

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: 'rgba(15,18,35,0.97)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, padding: '0.625rem 0.875rem', fontSize: '0.78rem' }}>
      <p style={{ color: 'var(--text-muted)', marginBottom: 4 }}>{label}</p>
      {payload.map((p, i) => (
        <p key={i} style={{ color: p.color, fontWeight: 600 }}>{p.name}: {p.value}</p>
      ))}
    </div>
  );
}

/* ─────────── SUB SECTIONS ─────────── */
function ReasonsSection({ reasons }) {
  return (
    <div className="rca-card">
      <div className="rca-card-header">
        <div className="rca-card-title"><Lightbulb size={17} /> Identified Root Causes</div>
        <span className="rca-badge-count">{reasons.length} causes</span>
      </div>
      <div className="reasons-list">
        {reasons.map((r) => {
          const cfg = REASON_CONFIG[r.type];
          return (
            <div key={r.id} className="reason-row" style={{ borderColor: cfg.border, background: cfg.bg }}>
              <div className="reason-icon-wrap">
                <span style={{ fontSize: '1.25rem' }}>{r.icon}</span>
              </div>
              <div style={{ flex: 1 }}>
                <div className="reason-header">
                  <span className="reason-title">{r.title}</span>
                  <span className="reason-severity" style={{ color: cfg.color, background: `${cfg.color}18` }}>
                    {r.type === 'critical' ? <AlertTriangle size={11}/> : r.type === 'high' ? <TrendingDown size={11}/> : <Activity size={11}/>}
                    {cfg.label}
                  </span>
                </div>
                <p className="reason-detail">{r.detail}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function CorrelationSection({ data }) {
  return (
    <div className="rca-card">
      <div className="rca-card-header">
        <div className="rca-card-title"><Link2 size={17} /> Correlation Analysis</div>
        <span className="rca-subtitle">Factor vs NPS Impact</span>
      </div>

      <div className="corr-list">
        {data.map((c, i) => {
          const cfg = CORR_STRENGTH[c.strength];
          return (
            <div key={i} className="corr-row">
              <div className="corr-label-row">
                <span className="corr-factor">{c.factor}</span>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <span className="corr-strength" style={{ color: cfg.color }}>{c.strength}</span>
                  <span style={{ fontSize: '0.75rem', color: '#f43f5e', fontWeight: 700 }}>NPS {c.npsImpact}</span>
                  <span style={{ fontSize: '0.75rem', color: '#fb923c', fontWeight: 700 }}>Risk +{c.riskImpact}%</span>
                </div>
              </div>
              <div className="corr-bar-bg">
                <div className="corr-bar-fill" style={{ width: cfg.w, background: cfg.color }} />
              </div>
            </div>
          );
        })}
      </div>

      {/* Scatter: Knowledge vs NPS */}
    </div>
  );
}

function TopBottomSection({ data, geoData }) {
  return (
    <div className="rca-card">
      <div className="rca-card-header">
        <div className="rca-card-title"><BarChart2 size={17} /> Top / Bottom Benchmarking</div>
        <span className="rca-subtitle">By {data.metric}</span>
      </div>
      <div className="topbottom-grid">
        <div>
          <div className="tb-label top">▲ Best Performers</div>
          {data.top.map((t, i) => (
            <div key={i} className="tb-row">
              <span className="tb-rank top">{i + 1}</span>
              <span className="tb-name">{t.name}</span>
              <div className="tb-bar-wrap">
                <div className="tb-bar" style={{ width: `${(t.val / 10) * 100}%`, background: 'var(--success)' }} />
              </div>
              <span className="tb-val" style={{ color: 'var(--success)' }}>{t.val}</span>
            </div>
          ))}
        </div>
        <div>
          <div className="tb-label bottom">▼ Lowest Performers</div>
          {data.bottom.map((t, i) => (
            <div key={i} className={`tb-row ${t.name.startsWith(geoData.geo) ? 'highlighted' : ''}`}>
              <span className="tb-rank bottom">{i + 1}</span>
              <span className="tb-name">
                {t.name}
                {t.name.startsWith(geoData.geo) && <span className="selected-geo-tag">← this geo</span>}
              </span>
              <div className="tb-bar-wrap">
                <div className="tb-bar" style={{ width: `${(t.val / 10) * 100}%`, background: 'var(--danger)' }} />
              </div>
              <span className="tb-val" style={{ color: 'var(--danger)' }}>{t.val}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Scatter Chart: Training vs NPS */}
      <div style={{ marginTop: '1.25rem' }}>
        <div className="rca-subtitle" style={{ marginBottom: 8 }}>Agent Training Hours vs NPS Score</div>
        <div style={{ height: 200 }}>
          <ResponsiveContainer>
            <ScatterChart margin={{ left: -15, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" />
              <XAxis dataKey="x" name="Training hrs" stroke="var(--text-muted)" fontSize={11} tickLine={false} label={{ value: 'Avg Training Hrs', position: 'insideBottom', offset: -2, fill: 'var(--text-muted)', fontSize: 10 }} />
              <YAxis dataKey="y" name="NPS" stroke="var(--text-muted)" fontSize={11} tickLine={false} domain={[0, 10]} label={{ value: 'NPS', angle: -90, position: 'insideLeft', fill: 'var(--text-muted)', fontSize: 10 }} />
              <Tooltip cursor={{ strokeDasharray: '3 3' }} content={({ active, payload }) => {
                if (!active || !payload?.length) return null;
                const d = payload[0].payload;
                return (
                  <div style={{ background: 'rgba(15,18,35,0.97)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, padding: '0.5rem 0.75rem', fontSize: '0.75rem' }}>
                    <p style={{ color: '#a78bfa', fontWeight: 700 }}>{d.label}</p>
                    <p style={{ color: 'var(--text-muted)' }}>Training: {d.x}h · NPS: {d.y}</p>
                  </div>
                );
              }} />
              <Scatter data={geoData.scatter} fill="var(--primary)" opacity={0.85} />
            </ScatterChart>
          </ResponsiveContainer>
        </div>
        <p style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginTop: 4 }}>
          <Brain size={11} style={{ display: 'inline', marginRight: 4 }}/>
          AI Insight: Strong positive correlation (r = 0.87) — more training hours = significantly higher NPS.
        </p>
      </div>
    </div>
  );
}

function TrendSection({ trend }) {
  return (
    <div className="rca-card">
      <div className="rca-card-header">
        <div className="rca-card-title"><Activity size={17} /> Trend Analysis (Last 5 Weeks)</div>
        <div className="trend-legend">
          <span style={{ color: '#f43f5e' }}>● Risk %</span>
          <span style={{ color: '#0ea5e9' }}>● Compliance</span>
          <span style={{ color: '#8b5cf6' }}>● NPS</span>
        </div>
      </div>

      <div style={{ height: 260 }}>
        <ResponsiveContainer>
          <LineChart data={trend} margin={{ left: -15, right: 10 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" vertical={false} />
            <XAxis dataKey="week" stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} />
            <YAxis yAxisId="left"  stroke="var(--text-muted)" fontSize={11} tickLine={false} axisLine={false} />
            <YAxis yAxisId="right" orientation="right" stroke="var(--text-muted)" fontSize={11} tickLine={false} axisLine={false} domain={[0, 10]} />
            <Tooltip content={<CustomTooltip />} />
            <ReferenceLine yAxisId="left" y={90} stroke="rgba(14,165,233,0.4)" strokeDasharray="4 4" label={{ value: 'Compliance Target', position: 'insideTopLeft', fill: 'rgba(14,165,233,0.6)', fontSize: 10 }} />
            <ReferenceLine yAxisId="right" y={7.5} stroke="rgba(139,92,246,0.4)" strokeDasharray="4 4" label={{ value: 'NPS Target', position: 'insideTopRight', fill: 'rgba(139,92,246,0.6)', fontSize: 10 }} />
            <Line yAxisId="left"  type="monotone" dataKey="compliance" name="Compliance %" stroke="#0ea5e9" strokeWidth={2.5} dot={{ r: 4 }} />
            <Line yAxisId="left"  type="monotone" dataKey="risk"       name="Risk %"       stroke="#f43f5e" strokeWidth={2.5} dot={{ r: 4 }} />
            <Line yAxisId="right" type="monotone" dataKey="nps"        name="NPS Score"    stroke="#8b5cf6" strokeWidth={3}   dot={{ r: 5, fill: '#8b5cf6' }} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Summary delta row */}
      <div className="trend-delta-row">
        {[
          { label: 'NPS Change', from: trend[0].nps, to: trend[trend.length-1].nps, suffix: '', invert: false },
          { label: 'Compliance Change', from: trend[0].compliance, to: trend[trend.length-1].compliance, suffix: '%', invert: false },
          { label: 'Risk Change', from: trend[0].risk, to: trend[trend.length-1].risk, suffix: '%', invert: true },
        ].map((d, i) => {
          const delta = (d.to - d.from).toFixed(1);
          const bad = d.invert ? delta > 0 : delta < 0;
          const color = bad ? 'var(--danger)' : delta == 0 ? 'var(--text-muted)' : 'var(--success)';
          return (
            <div key={i} className="delta-chip" style={{ borderColor: `${color}33` }}>
              <span style={{ color: 'var(--text-muted)', fontSize: '0.72rem' }}>{d.label}</span>
              <span style={{ color, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 4 }}>
                {bad ? <ArrowDown size={13}/> : delta > 0 ? <ArrowUp size={13}/> : <Minus size={13}/>}
                {delta > 0 ? '+' : ''}{delta}{d.suffix}
              </span>
            </div>
          );
        })}
        <div className="delta-chip" style={{ borderColor: 'rgba(244,63,94,0.3)', background: 'rgba(244,63,94,0.06)' }}>
          <span style={{ color: 'var(--text-muted)', fontSize: '0.72rem' }}>Trend Direction</span>
          <span style={{ color: 'var(--danger)', fontWeight: 700, display: 'flex', alignItems: 'center', gap: 4 }}>
            <TrendingDown size={14}/> Declining
          </span>
        </div>
      </div>
    </div>
  );
}

/* ─────────── BAD CATEGORY CHIPS ─────────── */
function BadCategoryChips({ categories }) {
  return (
    <div className="bad-cats-row">
      <span className="bad-cats-label"><AlertTriangle size={13}/> Failing Categories:</span>
      {categories.map(c => (
        <span key={c} className="bad-cat-chip">{c}</span>
      ))}
    </div>
  );
}

/* ─────────── MAIN PAGE ─────────── */
export default function RCAAnalysis() {
  const [selectedGeo, setSelectedGeo] = useState('LATAM');
  const data = GEO_DATA[selectedGeo];

  return (
    <div className="rca-root animate-fade-in">
      {/* Header + Geo Selector */}
      <div className="rca-top-bar glass-panel">
        <div className="rca-top-left">
          <div className="rca-geo-icon">
            <Globe2 size={22} color="var(--primary)" />
          </div>
          <div>
            <h2 style={{ fontWeight: 700, fontSize: '1rem', marginBottom: 2 }}>
              RCA for: <span style={{ color: 'var(--primary)' }}>{data.geo}</span>
            </h2>
            <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{data.group}</p>
          </div>
          <div className="geo-health-badge" style={{ color: 'var(--danger)', background: 'rgba(239,68,68,0.1)', borderColor: 'rgba(239,68,68,0.25)' }}>
            Health: <strong>{data.health}</strong> / Critical
          </div>
        </div>
        <div className="geo-tabs">
          {GEO_OPTIONS.map(g => (
            <button
              key={g}
              className={`geo-tab ${selectedGeo === g ? 'active' : ''}`}
              onClick={() => setSelectedGeo(g)}
            >
              <Globe2 size={14} /> {g}
            </button>
          ))}
        </div>
      </div>

      {/* Failing Metrics badges */}
      <BadCategoryChips categories={data.badCategories} />

      {/* Main 2-col layout */}
      <div className="rca-layout">
        {/* LEFT column */}
        <div className="rca-col">
          <ReasonsSection reasons={data.reasons} />
          <TrendSection trend={data.trend} />
        </div>
        {/* RIGHT column */}
        <div className="rca-col">
          <CorrelationSection data={data.correlations} />
          <TopBottomSection data={data.topBottom} geoData={data} />
        </div>
      </div>
    </div>
  );
}
