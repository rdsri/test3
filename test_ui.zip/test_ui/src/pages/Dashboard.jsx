import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, LineChart, Line } from 'recharts';
import { PhoneCall, AlertTriangle, TrendingUp, Award, ChevronDown } from 'lucide-react';

const sentimentData = [
  { name: 'NA', score: 8.2, compliance: 95 },
  { name: 'EMEA', score: 7.5, compliance: 88 },
  { name: 'APAC', score: 8.6, compliance: 92 },
  { name: 'LATAM', score: 7.1, compliance: 85 },
];

const trendData = [
  { day: 'Mon', calls: 320, nps: 7.2 },
  { day: 'Tue', calls: 450, nps: 7.5 },
  { day: 'Wed', calls: 512, nps: 7.8 },
  { day: 'Thu', calls: 410, nps: 7.6 },
  { day: 'Fri', calls: 380, nps: 8.1 },
  { day: 'Sat', calls: 150, nps: 8.5 },
  { day: 'Sun', calls: 120, nps: 8.7 },
];

export default function Dashboard() {
  return (
    <div className="animate-fade-in">
      {/* Filters Row */}
      <div className="glass-panel p-4 mb-6 flex gap-4">
        <select className="select flex-1">
          <option value="">All IMUs</option>
          <option value="tech">Tech Support</option>
          <option value="sales">Sales</option>
        </select>
        <select className="select flex-1">
          <option value="">All Clients</option>
          <option value="c1">Client A</option>
          <option value="c2">Client B</option>
        </select>
        <select className="select flex-1">
          <option value="">All Processes</option>
          <option value="p1">Billing</option>
          <option value="p2">Troubleshooting</option>
        </select>
        <select className="select flex-1">
          <option value="">All Geos</option>
          <option value="na">North America</option>
          <option value="emea">EMEA</option>
        </select>
        <button className="btn btn-primary">Apply Filters</button>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-4 gap-6 mb-6">
        {[
          { title: 'Total Audits', value: '12,450', sub: '+14% from last week', icon: <PhoneCall size={24} />, color: 'var(--primary)' },
          { title: 'Average NPS', value: '7.8', sub: 'Target: 8.0', icon: <Award size={24} />, color: 'var(--success)' },
          { title: 'Risks Identified', value: '342', sub: '-5% from last week', icon: <AlertTriangle size={24} />, color: 'var(--danger)' },
          { title: 'Avg AI Conf.', value: '94%', sub: 'High accuracy', icon: <TrendingUp size={24} />, color: 'var(--secondary)' },
        ].map((stat, i) => (
          <div key={i} className="glass-panel p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <div className="text-muted text-sm font-medium">{stat.title}</div>
                <div className="text-3xl font-bold mt-1">{stat.value}</div>
              </div>
              <div style={{ color: stat.color, background: `${stat.color}20`, padding: '0.5rem', borderRadius: 'var(--radius-md)' }}>
                {stat.icon}
              </div>
            </div>
            <div className="text-sm text-muted">{stat.sub}</div>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-2 gap-6 mb-6">
        <div className="glass-panel p-6 flex flex-col">
          <h2 className="text-lg mb-6">Sentiment & Compliance by Region</h2>
          <div className="flex-1" style={{ minHeight: '300px' }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={sentimentData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" vertical={false} />
                <XAxis dataKey="name" stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ background: 'var(--bg-surface-hover)', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)' }} 
                  itemStyle={{ color: 'var(--text-main)' }} 
                />
                <Bar dataKey="score" name="NPS Score" fill="var(--primary)" radius={[4, 4, 0, 0]} barSize={32} />
                <Bar dataKey="compliance" name="Compliance %" fill="var(--secondary)" radius={[4, 4, 0, 0]} barSize={32} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-panel p-6 flex flex-col">
          <h2 className="text-lg mb-6">Weekly Volume & NPS Trend</h2>
          <div className="flex-1" style={{ minHeight: '300px' }}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trendData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" vertical={false} />
                <XAxis dataKey="day" stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis yAxisId="left" stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis yAxisId="right" orientation="right" stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} domain={[0, 10]} />
                <Tooltip 
                  contentStyle={{ background: 'var(--bg-surface-hover)', border: '1px solid var(--border-color)', borderRadius: 'var(--radius-md)' }} 
                  itemStyle={{ color: 'var(--text-main)' }} 
                />
                <Line yAxisId="left" type="monotone" dataKey="calls" name="Call Volume" stroke="var(--secondary)" strokeWidth={3} dot={{ r: 4, fill: 'var(--secondary)' }} />
                <Line yAxisId="right" type="monotone" dataKey="nps" name="NPS" stroke="var(--success)" strokeWidth={3} dot={{ r: 4, fill: 'var(--success)' }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
      
      {/* Recent Audits Table Placeholder */}
      <div className="glass-panel">
        <div className="p-6 border-b" style={{ borderColor: 'var(--border-color)' }}>
          <h2 className="text-lg">Recent Audits Needs Review</h2>
        </div>
        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th>Interaction ID</th>
                <th>Agent</th>
                <th>Category (IMU/Client/Process/Geo)</th>
                <th>Risk Level</th>
                <th>NPS</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {['INT-88392', 'INT-88393', 'INT-88394', 'INT-88395'].map((id, i) => (
                <tr key={i}>
                  <td className="font-medium">{id}</td>
                  <td>Sarah Jenkins</td>
                  <td className="text-muted">Tech / Acme / Billing / NA</td>
                  <td>
                    <span className={`badge ${i % 2 === 0 ? 'badge-danger' : 'badge-warning'}`}>
                      {i % 2 === 0 ? 'High' : 'Medium'}
                    </span>
                  </td>
                  <td>{i % 2 === 0 ? '4.5' : '7.0'}</td>
                  <td><button className="btn btn-secondary text-xs">Review</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
