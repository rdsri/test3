import { useState } from 'react';
import {
  CheckCircle2, AlertTriangle, XCircle, ChevronRight, X,
  TrendingUp, TrendingDown, Minus, Info, Target, ShieldCheck,
  Smile, Brain, Zap, AlertCircle, ArrowUpRight, Scale
} from 'lucide-react';
import './Analytics.css';

/* ─────────────── DATA ─────────────── */
const THRESHOLDS = [
  { key: 'nps',        label: 'NPS Score',         threshold: 7.5,  unit: '/10',  icon: <TrendingUp size={16}/>,   color: '#8b5cf6' },
  { key: 'aiScore',    label: 'AI Score',           threshold: 80,   unit: '%',    icon: <Brain size={16}/>,        color: '#0ea5e9' },
  { key: 'resolution', label: 'Resolution Rate',    threshold: 85,   unit: '%',    icon: <CheckCircle2 size={16}/>, color: '#10b981' },
  { key: 'compliance', label: 'Compliance',         threshold: 90,   unit: '%',    icon: <ShieldCheck size={16}/>,  color: '#f59e0b' },
  { key: 'sentiment',  label: 'Positive Sentiment', threshold: 75,   unit: '%',    icon: <Smile size={16}/>,        color: '#ec4899' },
  { key: 'cast',       label: 'CAST Score',         threshold: 70,   unit: '%',    icon: <Scale size={16}/>,        color: '#14b8a6' },
  { key: 'aiConf',     label: 'AI Confidence',      threshold: 90,   unit: '%',    icon: <Brain size={16}/>,        color: '#a78bfa' },
  { key: 'risk',       label: 'Risk Rate',          threshold: 10,   unit: '%',    icon: <AlertTriangle size={16}/>,color: '#f43f5e', inverted: true },
  { key: 'escalation', label: 'Escalation Rate',   threshold: 8,    unit: '%',    icon: <AlertCircle size={16}/>,  color: '#fb923c', inverted: true },
];

const GROUPS = [
  {
    id: 'g1', imu: 'Tech Support', client: 'Acme Corp', process: 'Billing', geo: 'North America',
    health: 92,
    metrics: { nps: 8.9, aiScore: 91, resolution: 93, compliance: 97, sentiment: 88, cast: 85, aiConf: 96, risk: 4, escalation: 3 },
  },
  {
    id: 'g2', imu: 'Sales', client: 'Globex', process: 'Onboarding', geo: 'EMEA',
    health: 61,
    metrics: { nps: 5.8, aiScore: 67, resolution: 72, compliance: 78, sentiment: 58, cast: 60, aiConf: 85, risk: 22, escalation: 17 },
  },
  {
    id: 'g3', imu: 'Customer Service', client: 'Initech', process: 'Troubleshooting', geo: 'APAC',
    health: 78,
    metrics: { nps: 7.2, aiScore: 82, resolution: 88, compliance: 85, sentiment: 76, cast: 74, aiConf: 92, risk: 11, escalation: 9 },
  },
  {
    id: 'g4', imu: 'Tech Support', client: 'Hooli', process: 'Tech Setup', geo: 'LATAM',
    health: 44,
    metrics: { nps: 3.9, aiScore: 52, resolution: 55, compliance: 61, sentiment: 42, cast: 48, aiConf: 78, risk: 34, escalation: 28 },
  },
  {
    id: 'g5', imu: 'Sales', client: 'Acme Corp', process: 'Renewal', geo: 'North America',
    health: 85,
    metrics: { nps: 8.1, aiScore: 87, resolution: 90, compliance: 91, sentiment: 83, cast: 79, aiConf: 95, risk: 7, escalation: 5 },
  },
  {
    id: 'g6', imu: 'Customer Service', client: 'Globex', process: 'Billing', geo: 'EMEA',
    health: 55,
    metrics: { nps: 5.1, aiScore: 60, resolution: 63, compliance: 69, sentiment: 52, cast: 55, aiConf: 82, risk: 28, escalation: 19 },
  },
];

/* ─────────────── HELPERS ─────────────── */
function metricStatus(key, value) {
  const t = THRESHOLDS.find(t => t.key === key);
  if (!t) return 'good';
  if (t.inverted) {
    if (value <= t.threshold * 0.6) return 'good';
    if (value <= t.threshold) return 'warning';
    return 'bad';
  } else {
    if (value >= t.threshold * 1.05) return 'good';
    if (value >= t.threshold * 0.9) return 'warning';
    return 'bad';
  }
}

function healthColor(h) {
  if (h >= 80) return 'var(--success)';
  if (h >= 60) return 'var(--warning)';
  return 'var(--danger)';
}

function healthLabel(h) {
  if (h >= 80) return 'Healthy';
  if (h >= 60) return 'At Risk';
  return 'Critical';
}

function StatusIcon({ status }) {
  if (status === 'good')    return <CheckCircle2 size={14} color="var(--success)" />;
  if (status === 'warning') return <AlertTriangle size={14} color="var(--warning)" />;
  return <XCircle size={14} color="var(--danger)" />;
}

function statusBadgeClass(status) {
  if (status === 'good')    return 'badge badge-success';
  if (status === 'warning') return 'badge badge-warning';
  return 'badge badge-danger';
}

function formatValue(key, value) {
  const t = THRESHOLDS.find(t => t.key === key);
  if (!t) return value;
  if (t.key === 'nps') return `${value}${t.unit}`;
  return `${value}${t.unit}`;
}

/* ─────────────── THRESHOLD OVERVIEW ─────────────── */
function ThresholdOverview() {
  return (
    <section className="analytics-section">
      <div className="section-header">
        <div>
          <h2 className="text-xl">Threshold Overview</h2>
          <p className="text-muted text-sm">Benchmark values used to evaluate every interaction group</p>
        </div>
        <span className="badge badge-primary">{THRESHOLDS.length} Categories</span>
      </div>

      <div className="threshold-grid">
        {THRESHOLDS.map(t => (
          <div key={t.key} className="threshold-chip glass-panel">
            <div className="threshold-chip-icon" style={{ background: `${t.color}20`, color: t.color }}>
              {t.icon}
            </div>
            <div className="threshold-chip-body">
              <span className="threshold-chip-label">{t.label}</span>
              <div className="threshold-chip-value">
                <span style={{ color: t.color, fontWeight: 700, fontSize: '1.1rem' }}>
                  {t.inverted ? '≤' : '≥'} {t.threshold}{t.unit}
                </span>
              </div>
              <div className="threshold-bar-bg">
                <div
                  className="threshold-bar-fill"
                  style={{
                    width: t.inverted ? `${t.threshold * 4}%` : `${t.threshold}%`,
                    background: t.color
                  }}
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ─────────────── GROUP CARD ─────────────── */
function GroupCard({ group, onClick }) {
  const failingCount  = THRESHOLDS.filter(t => metricStatus(t.key, group.metrics[t.key]) === 'bad').length;
  const warningCount  = THRESHOLDS.filter(t => metricStatus(t.key, group.metrics[t.key]) === 'warning').length;
  const hColor = healthColor(group.health);

  return (
    <div className="group-card glass-panel" onClick={() => onClick(group)}>
      {/* Health stripe */}
      <div className="card-stripe" style={{ background: hColor }} />

      <div className="card-top">
        <div className="card-title-block">
          <h3 className="card-title">{group.imu} · {group.client}</h3>
          <p className="card-subtitle">{group.process} · {group.geo}</p>
        </div>
        <div className="card-health" style={{ '--hc': hColor }}>
          <span className="health-score" style={{ color: hColor }}>{group.health}</span>
          <span className="health-label" style={{ color: hColor }}>{healthLabel(group.health)}</span>
        </div>
      </div>

      {/* Health bar */}
      <div className="progress-bg" style={{ marginBottom: '1rem' }}>
        <div className="progress-fill" style={{ width: `${group.health}%`, background: hColor }} />
      </div>

      {/* Mini metric pills */}
      <div className="card-metrics-row">
        {THRESHOLDS.slice(0, 5).map(t => {
          const status = metricStatus(t.key, group.metrics[t.key]);
          return (
            <div key={t.key} className={`metric-pill ${status}`}>
              <StatusIcon status={status} />
              <span>{t.label.split(' ')[0]}</span>
            </div>
          );
        })}
      </div>

      <div className="card-footer">
        <div className="card-flags">
          {failingCount > 0 && (
            <span className="badge badge-danger"><XCircle size={11}/> {failingCount} failing</span>
          )}
          {warningCount > 0 && (
            <span className="badge badge-warning"><AlertTriangle size={11}/> {warningCount} warning</span>
          )}
          {failingCount === 0 && warningCount === 0 && (
            <span className="badge badge-success"><CheckCircle2 size={11}/> All passing</span>
          )}
        </div>
        <button className="drill-btn">
          Drill Down <ChevronRight size={14} />
        </button>
      </div>
    </div>
  );
}

/* ─────────────── DRILL-DOWN MODAL ─────────────── */
function DrillDownModal({ group, onClose }) {
  if (!group) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-drawer" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="modal-header">
          <div>
            <h2 className="text-xl">{group.imu} – {group.client}</h2>
            <p className="text-muted text-sm">{group.process} · {group.geo}</p>
          </div>
          <div className="modal-header-right">
            <div className="modal-health" style={{ color: healthColor(group.health) }}>
              <span style={{ fontSize: '2.2rem', fontWeight: 800, lineHeight: 1 }}>{group.health}</span>
              <span style={{ fontSize: '0.75rem', marginTop: 2 }}>Health Score</span>
            </div>
            <button className="close-btn" onClick={onClose}><X size={20} /></button>
          </div>
        </div>

        {/* Category Table */}
        <div className="modal-body">
          <div className="modal-section-label">
            <Target size={15} /> Category-wise Analysis vs Thresholds
          </div>
          <div className="metric-rows">
            {THRESHOLDS.map(t => {
              const val = group.metrics[t.key];
              const status = metricStatus(t.key, val);
              const diff = t.inverted
                ? t.threshold - val   // negative diff means val > threshold = bad
                : val - t.threshold;  // positive = good

              return (
                <div key={t.key} className={`metric-row-detail ${status}`}>
                  <div className="mrd-left">
                    <div className="mrd-icon" style={{ color: t.color, background: `${t.color}18` }}>
                      {t.icon}
                    </div>
                    <div>
                      <div className="mrd-name">{t.label}</div>
                      {status === 'bad' && (
                        <div className="mrd-reason">
                          {t.inverted
                            ? `Rate is ${Math.abs(diff).toFixed(0)}${t.unit} above acceptable limit — needs immediate attention`
                            : `Score is ${Math.abs(diff).toFixed(1)}${t.unit} below the required threshold — underperforming`}
                        </div>
                      )}
                      {status === 'warning' && (
                        <div className="mrd-reason warning">
                          {t.inverted
                            ? `Approaching the limit — monitor closely`
                            : `Slightly below benchmark — improvement recommended`}
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="mrd-right">
                    <div className="mrd-values">
                      <span className="mrd-actual" style={{ color: status === 'good' ? 'var(--success)' : status === 'warning' ? 'var(--warning)' : 'var(--danger)' }}>
                        {formatValue(t.key, val)}
                      </span>
                      <span className="mrd-sep">/</span>
                      <span className="mrd-threshold text-muted">
                        {t.inverted ? '≤' : '≥'}{t.threshold}{t.unit} threshold
                      </span>
                    </div>
                    <div className="mrd-bar-bg">
                      <div
                        className="mrd-bar-fill"
                        style={{
                          width: t.key === 'nps'
                            ? `${(val / 10) * 100}%`
                            : `${Math.min(val, 100)}%`,
                          background: status === 'good' ? 'var(--success)' : status === 'warning' ? 'var(--warning)' : 'var(--danger)',
                        }}
                      />
                      {/* Threshold marker */}
                      <div
                        className="mrd-threshold-marker"
                        style={{
                          left: t.key === 'nps'
                            ? `${(t.threshold / 10) * 100}%`
                            : `${t.threshold}%`
                        }}
                      />
                    </div>
                    <span className={statusBadgeClass(status)}>
                      <StatusIcon status={status}/>&nbsp;
                      {status.charAt(0).toUpperCase() + status.slice(1)}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─────────────── MAIN COMPONENT ─────────────── */
export default function Analytics() {
  const [selectedGroup, setSelectedGroup] = useState(null);
  const [filterHealth, setFilterHealth] = useState('all');

  const filtered = GROUPS.filter(g => {
    if (filterHealth === 'healthy')  return g.health >= 80;
    if (filterHealth === 'at-risk')  return g.health >= 60 && g.health < 80;
    if (filterHealth === 'critical') return g.health < 60;
    return true;
  });

  return (
    <div className="analytics-root animate-fade-in">
      {/* 1. Threshold Overview */}
      <ThresholdOverview />

      {/* 2. Grouped Results */}
      <section className="analytics-section">
        <div className="section-header">
          <div>
            <h2 className="text-xl">Group Performance Cards</h2>
            <p className="text-muted text-sm">
              IMU – Client – Process – Geo · Click any card to drill down
            </p>
          </div>
          <div className="filter-tabs">
            {[
              { value: 'all', label: 'All' },
              { value: 'healthy', label: '✓ Healthy' },
              { value: 'at-risk', label: '⚠ At Risk' },
              { value: 'critical', label: '✗ Critical' },
            ].map(f => (
              <button
                key={f.value}
                className={`filter-tab ${filterHealth === f.value ? 'active' : ''}`}
                onClick={() => setFilterHealth(f.value)}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        <div className="cards-grid">
          {filtered.map(g => (
            <GroupCard key={g.id} group={g} onClick={setSelectedGroup} />
          ))}
        </div>
      </section>

      {/* 3. Drill-Down Modal */}
      {selectedGroup && (
        <DrillDownModal group={selectedGroup} onClose={() => setSelectedGroup(null)} />
      )}
    </div>
  );
}
