import { Layers } from 'lucide-react';

export default function Tab3() {
  return (
    <div className="animate-fade-in" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '60vh', gap: '1rem' }}>
      <div style={{ background: 'rgba(14,165,233,0.1)', padding: '2rem', borderRadius: '50%' }}>
        <Layers size={52} color="var(--secondary)" />
      </div>
      <h2 style={{ fontSize: '1.5rem', fontWeight: 700 }}>Tab 3 — Coming Soon</h2>
      <p className="text-muted" style={{ textAlign: 'center', maxWidth: 380 }}>
        This tab is reserved. Share the content and design requirements and it will be fully built in the next chat.
      </p>
      <div className="badge badge-primary" style={{ fontSize: '0.8rem', padding: '0.4rem 1rem' }}>Placeholder Active</div>
    </div>
  );
}
