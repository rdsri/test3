import { LayoutGrid } from 'lucide-react';

export default function Tab4() {
  return (
    <div className="animate-fade-in" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '60vh', gap: '1rem' }}>
      <div style={{ background: 'rgba(139,92,246,0.1)', padding: '2rem', borderRadius: '50%' }}>
        <LayoutGrid size={52} color="var(--primary)" />
      </div>
      <h2 style={{ fontSize: '1.5rem', fontWeight: 700 }}>Tab 4 — Coming Soon</h2>
      <p className="text-muted" style={{ textAlign: 'center', maxWidth: 380 }}>
        This tab is ready and waiting. Share the content and design requirements and it will be built out in the next chat.
      </p>
      <div className="badge badge-primary" style={{ fontSize: '0.8rem', padding: '0.4rem 1rem' }}>Placeholder Active</div>
    </div>
  );
}
