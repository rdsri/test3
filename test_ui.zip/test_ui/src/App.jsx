import { Routes, Route, useLocation } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Analytics from './pages/Analytics';
import AICourses from './pages/AICourses';
import RCAAnalysis from './pages/RCAAnalysis';
import CAPA from './pages/CAPA';

function App() {
  const location = useLocation();

  const getPageTitle = (pathname) => {
    switch (pathname) {
      case '/':         return 'Analytics';
      case '/courses':  return 'AI Courses';
      case '/rca':      return 'RCA Analysis';
      case '/capa':     return 'CAPA';
      default:          return 'Analytics';
    }
  };

  return (
    <div className="app-container">
      <Sidebar />
      <main className="main-content">
        <Header title={getPageTitle(location.pathname)} />
        <div className="page-content">
          <Routes>
            <Route path="/"        element={<Analytics />} />
            <Route path="/courses" element={<AICourses />} />
            <Route path="/rca"      element={<RCAAnalysis />} />
            <Route path="/capa"    element={<CAPA />} />
          </Routes>
        </div>
      </main>
    </div>
  );
}

export default App;
